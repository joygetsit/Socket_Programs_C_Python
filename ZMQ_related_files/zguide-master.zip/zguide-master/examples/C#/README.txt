Examples in C#
See LICENSE in examples directory
